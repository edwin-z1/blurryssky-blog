//
//  ToDoDataSource.h
//  BoringToDo
//
//  Created by blurryssky on 2019/3/7.
//  Copyright © 2019 blurryssky. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ToDoItem.h"

#import <ReactiveObjC/ReactiveObjC.h>

NS_ASSUME_NONNULL_BEGIN

@interface ToDoViewModel : NSObject

@property BOOL canSwitchOn;

- (RACSignal<NSString *> *)titleSignal;
@property (nonatomic, strong, readonly) RACSubject *itemsDidChangeSubject;
@property (nonatomic, strong, readonly) RACSubject<NSNumber *> *didRemoveItemSubject;
@property (nonatomic, strong, readonly, nullable) NSArray<ToDoItem *> *items;

- (void)loadToDoItems;
- (void)createToDoItem:(NSString *)title;
- (void)removeToDoItemAtIndex:(NSInteger)index;
- (void)item:(ToDoItem *)item changeSwitch:(BOOL)isOn;

@end

NS_ASSUME_NONNULL_END
