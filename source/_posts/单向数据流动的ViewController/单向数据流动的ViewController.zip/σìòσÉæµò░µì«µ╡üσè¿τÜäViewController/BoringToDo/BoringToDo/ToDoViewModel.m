//
//  ToDoDataSource.m
//  BoringToDo
//
//  Created by blurryssky on 2019/3/7.
//  Copyright © 2019 blurryssky. All rights reserved.
//

#import "ToDoViewModel.h"

#define DATA_PATH ([NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"ToDoItems"])

#define UserDefaultsKeyCanSwitchOn @"canSwitchOn"

@interface ToDoViewModel ()

@property (nonatomic, strong, nullable) NSMutableArray<ToDoItem *> *items;
@property (nonatomic, strong) RACSignal<NSMutableArray<ToDoItem *> *> *itemsSignal;

- (NSMutableArray<ToDoItem *> *)observableItems;

@end

@implementation ToDoViewModel

#pragma mark - Override

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

#pragma mark - Private

- (void)setup {
    _itemsSignal = RACObserve(self, items);
    [[_itemsSignal skip:1]
     subscribeNext:^(NSMutableArray<ToDoItem *> * _Nullable x) {
         [self saveToDoItems];
     }];
    
    _itemsDidChangeSubject = [RACSubject subject];
    _didRemoveItemSubject = [RACSubject<NSNumber *> subject];
}

- (void)saveToDoItems {
    NSData *archivedData = [NSKeyedArchiver archivedDataWithRootObject:_items requiringSecureCoding:YES error:nil];
    [archivedData writeToFile:DATA_PATH atomically:YES];
}

- (NSMutableArray<ToDoItem *> *)observableItems {
    return [self mutableArrayValueForKeyPath:@"items"];
}

#pragma mark - Public

- (BOOL)canSwitchOn {
    return [[NSUserDefaults standardUserDefaults] boolForKey:UserDefaultsKeyCanSwitchOn];;
}

- (void)setCanSwitchOn:(BOOL)canSwitchOn {
    [[NSUserDefaults standardUserDefaults] setBool:canSwitchOn forKey:UserDefaultsKeyCanSwitchOn];
}

- (RACSignal<NSString *> *)titleSignal {
    return [_itemsSignal map:^NSString* (NSMutableArray<ToDoItem *> *items) {
        NSInteger count = 0;
        for (ToDoItem *item in items) {
            if (!item.hasDone) {
                count ++;
            }
        }
        NSString *title = [NSString stringWithFormat:@"ToDoList(%ld)", (long)count];
        if (count == 0) {
            title = @"ToDoList";
        }
        return title;
    }];
}

- (void)loadToDoItems {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSData *archivedData = [NSData dataWithContentsOfFile:DATA_PATH];
        NSSet *classes = [NSSet setWithArray:@[[NSMutableArray class], [ToDoItem class], [NSDate class]]];
        self.items = [NSKeyedUnarchiver unarchivedObjectOfClasses:classes fromData:archivedData error:nil];
        if (self.items == nil) {
            self.items = [NSMutableArray array];
        }
        
        [self->_itemsDidChangeSubject sendNext:nil];
    });
}

- (void)createToDoItem:(NSString *)title {
    ToDoItem *item = [ToDoItem new];
    item.title = title;
    item.date = [NSDate date];
    item.hasDone = NO;
    [self.observableItems addObject:item];
    
    [_itemsDidChangeSubject sendNext:nil];
}

- (void)removeToDoItemAtIndex:(NSInteger)index {
    [self.observableItems removeObjectAtIndex:index];
    
    [_didRemoveItemSubject sendNext:@(index)];
}

- (void)item:(ToDoItem *)item changeSwitch:(BOOL)isOn {
    BOOL hasDone = isOn;
    if (!self.canSwitchOn && isOn) {
        hasDone = NO;
    }
    item.hasDone = hasDone;
    self.items = _items;
}

@end
