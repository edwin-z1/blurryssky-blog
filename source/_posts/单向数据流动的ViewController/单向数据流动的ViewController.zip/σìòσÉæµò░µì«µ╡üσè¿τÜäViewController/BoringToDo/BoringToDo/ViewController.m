//
//  ViewController.m
//  BoringToDo
//
//  Created by blurryssky on 2019/3/6.
//  Copyright © 2019 blurryssky. All rights reserved.
//

#import "ViewController.h"
#import "ToDoViewModel.h"
#import "ToDoTableCell.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate, ToDoTableCellDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UISwitch *leftBarItemSwitch;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *addBarItem;

@property (nonatomic, strong, nullable) ToDoViewModel *viewModel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setupViewModel];
    
    [self addRefreshControl];
    [_tableView.refreshControl beginRefreshing];
    [_tableView.refreshControl sendActionsForControlEvents:(UIControlEventValueChanged)];
}

#pragma mark - Private

- (void)setupViewModel {
    _viewModel = [ToDoViewModel new];
    
    [_leftBarItemSwitch setOn:_viewModel.canSwitchOn animated:YES];
    
    @weakify(self);
    [_viewModel.titleSignal subscribeNext:^(NSString * title) {
        @strongify(self);
        self.title = title;
    }];
    
    [_viewModel.itemsDidChangeSubject subscribeNext:^(id  _Nullable x) {
        @strongify(self);
        [self.tableView.refreshControl endRefreshing];
        [self.tableView reloadData];
    }];
    
    [_viewModel.didRemoveItemSubject subscribeNext:^(NSNumber * _Nullable idxNumber) {
        @strongify(self);
        [self.tableView deleteRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:idxNumber.integerValue inSection:0]] withRowAnimation:(UITableViewRowAnimationAutomatic)];
    }];
}

- (void)addRefreshControl {
    UIRefreshControl *refreshControl = [UIRefreshControl new];
    [refreshControl addTarget:self action:@selector(loadToDoItems) forControlEvents:(UIControlEventValueChanged)];
    _tableView.refreshControl = refreshControl;
}

- (void)loadToDoItems {
    [_viewModel loadToDoItems];
}

#pragma mark - Action

- (IBAction)handleLeftBarItemSwitch:(UISwitch *)sender {
    _viewModel.canSwitchOn = sender.isOn;
}

- (IBAction)handleAddBarItem:(UIBarButtonItem *)sender {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"新建" message:nil preferredStyle:(UIAlertControllerStyleAlert)];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"添加一个待办事项";
    }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleCancel) handler:nil];
    __weak typeof(alert) weakAlert = alert;
    UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
        [self.viewModel createToDoItem:weakAlert.textFields.firstObject.text];
    }];
    [alert addAction:cancel];
    [alert addAction:confirm];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _viewModel.items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ToDoTableCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ToDoTableCell class])];
    cell.item = _viewModel.items[indexPath.row];
    cell.delegate = self;
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [_viewModel removeToDoItemAtIndex:indexPath.row];
    }
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - ToDoTableCellDelegate

- (void)toDoTableCell:(ToDoTableCell *)cell item:(ToDoItem *)item didChangeSwitch:(BOOL)isOn {
    [_viewModel item:item changeSwitch:isOn];
}

@end
