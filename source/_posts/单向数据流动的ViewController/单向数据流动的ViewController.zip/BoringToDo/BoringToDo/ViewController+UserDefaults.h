//
//  ViewController+UserDefaults.h
//  BoringToDo
//
//  Created by blurryssky on 2019/3/11.
//  Copyright © 2019 blurryssky. All rights reserved.
//

#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ViewController (UserDefaults)

@property BOOL canSwitchOn;

@end

NS_ASSUME_NONNULL_END
